﻿/* Выполнил студент группы БПИ195
Горбачев Даниил Геннадьевич*/
#include <stdio.h>
#define HAVE_STRUCT_TIMESPEC
#include <pthread.h>
#include <iostream>
using namespace std;

pthread_mutex_t mutex;

int C[3][3];
int n;
double** a;
double** e;
const double epsilon = 10e-5;

/// <summary>
/// Вычисление определителя матрицы.
/// </summary>
/// <param name="mas"></param>
/// <param name="n"></param>
/// <returns></returns>
int Determinant(double** mas, int n) {
	int  det = 0, k = 1, di, dj;
	double** p;
	p = new double* [n];
	for (int i = 0; i < n; i++)
		p[i] = new double[n];
	int m = n - 1;

	if (n < 1)
		return 0;
	if (n == 1)
		return mas[0][0];
	if (n == 2)
		return mas[0][0] * mas[1][1] - (mas[1][0] * mas[0][1]);

	for (int i = 0; i < n; i++) {
		di = 0;
		for (int ki = 0; ki < n - 1; ki++) {
			//Проверка индекса строки
			if (ki == i) di = 1;
			dj = 0;
			for (int kj = 0; kj < n - 1; kj++) {
				//Проверка индекса столбца
				if (kj == 0) dj = 1;
				p[ki][kj] = mas[ki + di][kj + dj];
			}
		}
		det = det + k * mas[i][0] * Determinant(p, m);
		k = -k;
	}

	return det;
}

/// <summary>
/// Вычисление обратной матрицы для данной.
/// </summary>
/// <param name="param"></param>
/// <returns></returns>
void* InversionThreads(void* param) {
	//используем мьютекс, чтобы не было одновременного выполнения нескольких циклов
	pthread_mutex_lock(&mutex);

	int p = *(int*)param;
	double temp;

	//вычисляем ведущий элемент
	double master = a[p][p];
	int master_pos = p;

	for (int j = p; j < n; j++)
		if (fabs(a[j][p]) > fabs(master)) {
			master = a[j][p];
			master_pos = j;
		}

	if (fabs(master) > epsilon) {
		//меняем местами текущую строку со строкой с новым ведущим элементом
		for (int j = 0; j < n; j++) {
			temp = a[p][j];
			a[p][j] = a[master_pos][j];
			a[master_pos][j] = temp;

			temp = e[p][j];
			e[p][j] = e[master_pos][j];
			e[master_pos][j] = temp;
		}
		//изменяем строки, ведущий элемент - A[i][i]
		for (int j = 0; j < n; j++) {
			if (p != j) {
				temp = (a[j][p] / a[p][p]);
				for (int k = 0; k < n; k++) {
					a[j][k] -= a[p][k] * temp;
					e[j][k] -= e[p][k] * temp;
				}
			}
		}
	}

	pthread_mutex_unlock(&mutex);
	return NULL;
}

int main() {
	cout << "Enter the dimension of the matrix(n): ";
	cin >> n;

	a = new double* [n];
	for (int i = 0; i < n; i++)
		a[i] = new double[n];
	cout << endl << "Enter the matrix" << endl;
	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
		{
			cout << "a[" << i << "][" << j << "]: ";
			cin >> a[i][j];
		}

	int numOfThreads;
	cout << endl << "Enter the number of threads: ";
	cin >> numOfThreads;
	while (numOfThreads < 0 || numOfThreads > n) {
		cout << "Wrong number, try again: ";
		cin >> numOfThreads;
	}

	cout << endl << "Original matrix" << endl;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++)
			cout << a[i][j] << "\t";
		cout << endl;
	}

	//единичная матрица
	e = new double* [n];
	for (int i = 0; i < n; i++)
		e[i] = new double[n];
	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
			if (i != j)
				e[i][j] = 0.0;
			else
				e[i][j] = 1.0;

	pthread_mutex_init(&mutex, NULL);
	if (Determinant(a, n) != 0) {
		pthread_t* mythread = new pthread_t[numOfThreads];
		int* num = new int[n];
		for (int i = 0; i < n; i++) num[i] = i;

		//Создаем потоки и join-им их.
		for (int i = 0; i < numOfThreads; i++)
			pthread_create(&mythread[i], NULL, InversionThreads, (void*)(num + i));
		for (int i = 0; i < numOfThreads; i++)
			pthread_join(mythread[i], NULL);
		//Если кол-во потоков меньше размерности матрицы, то самостоятельно прогоняем остальные значения.
		for (int i = numOfThreads; i < n; i++)
			InversionThreads((void*)(num + i));

		//Нормирование
		double tempA;
		for (int i = 0; i < n; i++) {
			tempA = a[i][i];
			a[i][i] /= tempA;
			for (int j = 0; j < n; j++)
				e[i][j] /= tempA;
		}

		cout << endl << "Inverse matrix" << endl;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				fprintf(stdout, "%f\t", e[i][j]);
			}
			fprintf(stdout, "\n");
		}
	}
	else {
		cout << "The determinant is 0, it is impossible to calculate the inverse of the matrix!";
	}
	return 0;
}